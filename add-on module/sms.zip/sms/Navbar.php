<nav class="navbar navbar-expand-sm bg-light navbar-light py-3">
  <div class="container-fluid">
    <a class="navbar-brand fs-4" href="index.php">Society Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item mx-5">
          <a class="nav-link fs-5 text-dark" href="index.php">Home</a>
        </li>
        <li class="nav-item mx-5">
          <a class="nav-link fs-5 text-dark" href="Login.php">Login</a>
        </li>
       
      </ul>
    </div>
  </div>
</nav>