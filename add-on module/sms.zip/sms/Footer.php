<div class="container-fluid text-center">
    <div class="row">
        <div class="col-sm-12">
            <h6>Copyright © 2024-25, All Rights Reserved.</h6>
        </div>
    </div>
</div>